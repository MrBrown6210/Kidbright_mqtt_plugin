Blockly.Msg.BLINK_START_TITLE = "เริ่มกระพริบแอลอีดี";
Blockly.Msg.BLINK_START_TOOLTIP = "เริ่มกระพริบแอลอีดี";
Blockly.Msg.BLINK_START_HELPURL = "";
Blockly.Msg.BLINK_STOP_TITLE = "หยุดกระพริบแอลอีดี";
Blockly.Msg.BLINK_STOP_TOOLTIP = "หยุดกระพริบแอลอีดี";
Blockly.Msg.BLINK_STOP_HELPURL = "";

Blockly.Msg.BLINK_START_TITLE = "Start Blinking LED";
Blockly.Msg.BLINK_START_TOOLTIP = "Start Blinking LED";
Blockly.Msg.BLINK_START_HELPURL = "";
Blockly.Msg.BLINK_STOP_TITLE = "Stop Blinking LED";
Blockly.Msg.BLINK_STOP_TOOLTIP = "Stop Blinking LED";
Blockly.Msg.BLINK_STOP_HELPURL = "";
